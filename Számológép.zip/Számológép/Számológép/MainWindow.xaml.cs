﻿using System;
using System.Windows;
using System.Linq;

namespace Számológép;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }

    private void btnOsszead_Click(object sender, RoutedEventArgs e)
    {
        if(Hiba(txtAszam.Text, txtBszam.Text)) return;
        String eredmeny = $"{txtAszam.Text} + {txtBszam.Text} = {Convert.ToDouble(txtAszam.Text)+Convert.ToDouble(txtBszam.Text)}";
        MessageBox.Show("Az összeadás eredménye: " + eredmeny);
        lbEredmenyek.Items.Add(eredmeny);
    }

    private void btnKivon_Click(object sender, RoutedEventArgs e)
    {
        if(Hiba(txtAszam.Text, txtBszam.Text)) return;
        String eredmeny = $"{txtAszam.Text} - {txtBszam.Text} = {Convert.ToDouble(txtAszam.Text)-Convert.ToDouble(txtBszam.Text)}";
        MessageBox.Show("A kivonás eredménye: " + eredmeny);
        lbEredmenyek.Items.Add(eredmeny);
    }

    private void btnSzoroz_Click(object sender, RoutedEventArgs e)
    {
        if (Hiba(txtAszam.Text, txtBszam.Text)) return;
        String eredmeny = $"{txtAszam.Text} * {txtBszam.Text} = {Convert.ToDouble(txtAszam.Text)*Convert.ToDouble(txtBszam.Text)}";
        MessageBox.Show("A szorzás eredménye: " + eredmeny);
        lbEredmenyek.Items.Add(eredmeny);
    }

    private void btnOszt_Click(object sender, RoutedEventArgs e)
    {
        if (Hiba(txtAszam.Text, txtBszam.Text)) return;
        if (Convert.ToDouble(txtBszam.Text) == 0 || Convert.ToDouble(txtBszam.Text) == 0)
        {
            MessageBox.Show("0-val nem osztunk!");
            return;
        }
        String eredmeny = $"{txtAszam.Text} / {txtBszam.Text} = {Convert.ToDouble(txtAszam.Text)/Convert.ToDouble(txtBszam.Text)}";
        MessageBox.Show("Az osztás eredménye:" + eredmeny);
        lbEredmenyek.Items.Add(eredmeny);
    }

    private static bool Hiba(string? egyik, string? masik)
    {
        egyik ??= ""; //egyik = egyik==null ? "" : egyik;  VAGY  egyik = egyik ?? "";
        masik ??= "";
        if (egyik == "" && masik == "") MessageBox.Show("Mindkét szám hiányzik!");
        else if (egyik == "") MessageBox.Show("Az a szám hiányzik!");
        else if (masik == "") MessageBox.Show("A b szám hiányzik!");
        else if (!egyik.All(char.IsDigit) && !masik.All(char.IsDigit)) MessageBox.Show("Mindkét mezőbe szám kell!\nBüntetésből leállítom a programot!");
        else if (!egyik.All(char.IsDigit)) MessageBox.Show("Az a mezőbe is szám kell!\nBüntetésből leállítom a programot!");
        else if (!masik.All(char.IsDigit)) MessageBox.Show("A b mezőbe is szám kell!\nBüntetésből leállítom a programot!");
        return egyik=="" || masik == "";
    }
}
